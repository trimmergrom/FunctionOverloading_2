#pragma once
#include "Constants.h"

void Print(int arr[], const unsigned int n);
void Print1(int arr[], const unsigned int n);
void Print(double arr[], const unsigned int n);
void Print(float arr[], const unsigned int n);
void Print(int arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void Print(char arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void Print(double arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void Print(float arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void ReversPrint(int arr[], const unsigned n);
void ReversPrint1(int arr[], const unsigned n);
void ReversPrint(double arr[], const unsigned n);
void ReversPrint(float arr[], const unsigned n);
void ReversPrint(int arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void ReversPrint(double arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void ReversPrint(float arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);