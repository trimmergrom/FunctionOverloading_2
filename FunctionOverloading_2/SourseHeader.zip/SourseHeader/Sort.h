#pragma once
#include "Constants.h"
void SortArr(int arr[], const unsigned int n);
void SortArr(double arr[], const unsigned int n);
void SortArr(float arr[], const unsigned int n);
void SortArr(char arr[], const unsigned int n);
void SortArr(int arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void SortArr(double arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);
void SortArr(float arr[ROWS][COLS], const unsigned int ROWS, const unsigned int COLS);