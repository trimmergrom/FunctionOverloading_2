#pragma once
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <conio.h>
using namespace std;